"use client";
import { useCallback, useEffect, useState } from "react";

export function useLocalCollection<T>(key:string, seed:T[], options?: { mergeSeedById?: boolean }){
  const [items,setItems]=useState<T[]>(seed);
  const [ready,setReady]=useState(false);
  useEffect(()=>{
    try{
      const stored=window.localStorage.getItem(key);
      if(stored) {
        const parsed = JSON.parse(stored) as T[];
        if (options?.mergeSeedById) {
          const id = (item: T) => (item as { id?: string }).id;
          const storedById = new Map(parsed.map((item) => [id(item), item]));
          const merged = seed.map((item) => storedById.get(id(item)) || item);
          const additions = parsed.filter((item) => !seed.some((seedItem) => id(seedItem) === id(item)));
          setItems([...merged, ...additions]);
        } else setItems(parsed);
      }
    }catch{}
    setReady(true);
  },[key,options?.mergeSeedById,seed]);
  useEffect(()=>{
    if(!ready) return;
    window.localStorage.setItem(key,JSON.stringify(items));
  },[items,key,ready]);
  const reset=useCallback(()=>setItems(seed),[seed]);
  return {items,setItems,ready,reset};
}
