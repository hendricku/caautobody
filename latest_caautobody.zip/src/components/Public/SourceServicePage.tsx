import Link from "next/link";
import Button from "@/components/UI/Button";
import PageHero from "@/components/Common/PageHero";
import { services } from "@/lib/siteContent";
import type { ServiceContent } from "@/types/content";

export default function SourceServicePage({ service }: { service: ServiceContent }) {
  const relatedServices = services
    .filter((item) => item.slug !== service.slug && !["byd-approved-repairer-melbourne", "lexus-approved-body-shop-melbourne"].includes(item.slug))
    .slice(0, 3);

  return (
    <main className="source-service">
      <PageHero title={service.title} image={service.image} intro={service.intro} />

      <section className="source-service__story shell section-pad" aria-label={service.title}>
        <div className="source-service__copy hp-reveal">
          {service.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        </div>
        <aside className="source-service__contact hp-reveal" aria-label="Contact CA Autobody">
          <span>CA Autobody</span>
          <a href="tel:+61397727411">03 9772 7411</a>
          <p>7 Ashley Park Drive, Chelsea Heights, VIC 3196</p>
          <Button href="/contact" variant="gold" arrow>Contact us</Button>
        </aside>
      </section>

      <section className="source-service__related section-pad">
        <div className="shell">
          <div className="source-service__related-head hp-reveal">
            <h2>More repair services</h2>
            <Link className="text-link" href="/services">View all services <span aria-hidden="true">→</span></Link>
          </div>
          <nav className="source-service__related-list hp-reveal" aria-label="Related services">
            {relatedServices.map((item) => (
              <Link key={item.slug} href={`/services/${item.slug}`}>
                <span>{item.title}</span><b aria-hidden="true">→</b>
              </Link>
            ))}
          </nav>
        </div>
      </section>
    </main>
  );
}
