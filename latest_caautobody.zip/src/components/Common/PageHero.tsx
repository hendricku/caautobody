interface PageHeroProps {
  eyebrow?: string;
  title: string;
  image: string;
  intro?: string;
}

export default function PageHero({ eyebrow, title, image, intro }: PageHeroProps) {
  return (
    <section className="page-hero">
      <img src={image} alt="" aria-hidden="true" />
      <div className="page-hero__shade" />
      <div className="page-hero__topfade" aria-hidden="true" />
      <div className="page-hero__content shell">
        {eyebrow ? <span className="hp-eyebrow hp-eyebrow--light">{eyebrow}</span> : null}
        <h1>{title}</h1>
        {intro ? <p>{intro}</p> : null}
      </div>
    </section>
  );
}
