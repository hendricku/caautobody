import type { Metadata } from "next";
import PageHero from "@/components/Common/PageHero";
import FAQList from "@/components/Public/FAQList";
import { faqs } from "@/lib/siteContent";

export const metadata: Metadata = { title: "Frequently Asked Questions - CA Chelsea Autobody" };

export default function FAQPage(){
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.filter((item) => item.visible).map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1") },
    })),
  };

  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <PageHero
        eyebrow="Helpful information"
        title="Frequently Asked Questions"
        image="https://caautobody.com.au/wp-content/uploads/2021/06/homepage-spray-paint.jpg"
        intro="Frequently asked questions."
      />
      <section className="editorial-grid shell section-pad faq-intro hp-reveal">
        <div>
          <span className="eyebrow">Before your repair</span>
          <h2>Frequently asked questions.</h2>
        </div>
        <div className="copy-stack">
          <p>Find answers to common questions about CA Autobody.</p>
        </div>
      </section>
      <section className="shell faq-section-wrap">
        <FAQList items={faqs} />
      </section>
    </main>
  );
}
