import type { Metadata } from "next";
import Link from "next/link";
import PageHero from "@/components/Common/PageHero";
import { services } from "@/lib/siteContent";

export const metadata: Metadata = { title: "Auto Accident Repair Services Melbourne | CA Autobody" };

export default function ServicesPage() {
  return (
    <main>
      <PageHero
        eyebrow="Collision repair services"
        title="Auto accident repair services in Melbourne"
        image="https://caautobody.com.au/wp-content/uploads/2021/06/homepage-spray-paint.jpg"
        intro="One experienced workshop for accident damage, body repairs, refinishing, replacement transport and modern EV repair support."
      />

      <section className="services-directory shell section-pad" aria-labelledby="services-directory-title">
        <div className="services-directory__head hp-reveal">
          <div><span className="eyebrow">Our services</span><h2 id="services-directory-title">Find the support your vehicle needs.</h2></div>
          <p>Choose a service below for a clear overview. If you are not sure where to begin, call the workshop and our team will point you in the right direction.</p>
        </div>
        <div className="services-directory__list hp-reveal">
          {services.map((service) => (
            <Link key={service.slug} href={`/services/${service.slug}`}>
              <div><h3>{service.title}</h3><p>{service.intro}</p></div>
              <span aria-hidden="true">→</span>
              <span className="sr-only">View {service.title}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="services-reassurance">
        <div className="shell services-reassurance__grid hp-reveal">
          <div><span className="eyebrow light">One repair team</span><h2>A clear path from assessment to handover.</h2></div>
          <ol className="services-reassurance__points"><li>Assessment</li><li>Repair planning</li><li>Body and paint work</li><li>Quality handover</li></ol>
        </div>
      </section>
    </main>
  );
}
