import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ServicePage from "@/components/Public/ServicePage";
import { services } from "@/lib/siteContent";
export async function generateStaticParams(){return services.map((service)=>({slug:service.slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;const service=services.find((item)=>item.slug===slug);return service?{title:service.seoTitle,description:service.intro}:{};}
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const service=services.find((item)=>item.slug===slug);if(!service)notFound();return <ServicePage service={service!}/>;}
